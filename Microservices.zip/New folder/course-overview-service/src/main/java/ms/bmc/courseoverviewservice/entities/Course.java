package ms.bmc.courseoverviewservice.entities;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Course implements Serializable {
	
	public Course() {
		super();
	}
	public Course(String courseID, String courseName, String instructorName) {
		super();
		CourseID = courseID;
		CourseName = courseName;
		InstructorName = instructorName;
	}
	
	String CourseID;
	String CourseName;
	String InstructorName;
	
	
	
	public String getCourseID() {
		return CourseID;
	}
	public void setCourseID(String courseID) {
		CourseID = courseID;
	}
	public String getCourseName() {
		return CourseName;
	}
	public void setCourseName(String courseName) {
		CourseName = courseName;
	}
	public String getInstructorName() {
		return InstructorName;
	}
	public void setInstructorName(String instructorName) {
		InstructorName = instructorName;
	}
	
	

}
