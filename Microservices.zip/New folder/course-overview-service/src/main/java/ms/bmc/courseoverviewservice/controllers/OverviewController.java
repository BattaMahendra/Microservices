package ms.bmc.courseoverviewservice.controllers;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import ms.bmc.courseoverviewservice.entities.Course;
import ms.bmc.courseoverviewservice.entities.CourseOverview;
import ms.bmc.courseoverviewservice.entities.CourseRating;

@RestController
@RequestMapping("/co")
public class OverviewController {
	
	@Autowired
	RestTemplate restTemplate;
	
	@RequestMapping("/{empId}")
	public List<CourseOverview> getCourseOverview(@PathVariable("empId") String empId){
		
		List<CourseRating> ratings=Arrays.asList(
				
				new CourseRating("1234", 4),
				new CourseRating("1235", 3)
				
				);
		
		return ratings.stream().map(rating->{
			Course course=restTemplate
					.getForObject("http://localhost:9091/ci/1", Course.class);
			return new CourseOverview(course.getCourseName(), "desc", rating.getRating());
		}).collect(Collectors.toList());
	
//		return Collections
//				.singletonList(
//						new CourseOverview("Spring", "BackEnd dev", 3));	
	}

}
