package ms.bmc.courseoverviewservice.entities;

public class CourseOverview {
	
	public CourseOverview() {
		super();
	}
	public CourseOverview(String cName, String cDesc, int cRating) {
		super();
		this.cName = cName;
		this.cDesc = cDesc;
		this.cRating = cRating;
	}
	
	
	
	
	String cName;
	String cDesc;
	int cRating;
	
	
	
	
	
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcDesc() {
		return cDesc;
	}
	public void setcDesc(String cDesc) {
		this.cDesc = cDesc;
	}
	public int getcRating() {
		return cRating;
	}
	public void setcRating(int cRating) {
		this.cRating = cRating;
	}

}
