package ms.bmc.learnerratingsserv.entities;

public class CourseRating {
	
	public CourseRating(String courseId, int rating) {
		super();
		CourseId = courseId;
		this.rating = rating;
	}
	
	String CourseId;
	int rating;
	
	
	public String getCourseId() {
		return CourseId;
	}
	public void setCourseId(String courseId) {
		CourseId = courseId;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}

}
