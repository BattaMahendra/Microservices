package ms.bmc.learnerratingsserv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnerRatingsServApplicationTests {

	@Test
	void contextLoads() {
	}

}
