package ms.bmc.courseinfoserv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseInfoServApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourseInfoServApplication.class, args);
	}

}
