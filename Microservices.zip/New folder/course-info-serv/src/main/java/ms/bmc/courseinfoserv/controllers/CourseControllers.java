package ms.bmc.courseinfoserv.controllers;

import java.util.Collections;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ms.bmc.courseinfoserv.entities.Course;


@RestController
@RequestMapping("/ci")
public class CourseControllers {
	
	@GetMapping("/{courseId}")
	public List<Course> getCourseOverview(@PathVariable("courseId") String courseId){
		
		return Collections.singletonList(
						new Course(courseId, "Spring Boot", "Jack Sparrow")
						
						);
				
	}

}
