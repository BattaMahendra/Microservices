package ms.bmc.courseinfoserv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseInfoServApplicationTests {

	@Test
	void contextLoads() {
	}

}
